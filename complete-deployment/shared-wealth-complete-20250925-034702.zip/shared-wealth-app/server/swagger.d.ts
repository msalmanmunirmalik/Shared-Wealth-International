import { Express } from 'express';
export declare const setupSwagger: (app: Express) => void;
//# sourceMappingURL=swagger.d.ts.map