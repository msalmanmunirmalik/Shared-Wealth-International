import express from 'express';
declare const router: express.Router;
export default router;
//# sourceMappingURL=setup.d.ts.map