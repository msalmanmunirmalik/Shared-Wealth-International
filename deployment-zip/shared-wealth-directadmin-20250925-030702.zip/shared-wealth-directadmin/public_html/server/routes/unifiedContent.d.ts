import { type Router as ExpressRouter } from 'express';
declare const router: ExpressRouter;
export default router;
//# sourceMappingURL=unifiedContent.d.ts.map