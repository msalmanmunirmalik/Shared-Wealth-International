import { Router } from 'express';
declare const router: ReturnType<typeof Router>;
export default router;
//# sourceMappingURL=reactions.d.ts.map