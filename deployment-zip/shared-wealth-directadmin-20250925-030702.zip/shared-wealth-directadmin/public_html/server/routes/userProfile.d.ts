import express from 'express';
declare const router: express.Router;
export default router;
//# sourceMappingURL=userProfile.d.ts.map