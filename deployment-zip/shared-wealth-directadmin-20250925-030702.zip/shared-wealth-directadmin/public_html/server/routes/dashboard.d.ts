import { Router } from 'express';
declare const router: ReturnType<typeof Router>;
export default router;
//# sourceMappingURL=dashboard.d.ts.map